// #ifndef CLICK_H
// #define CLICK_H

// #include "Rect.h"

// // std::vector<Rect> griddd;

// struct Click{

//     int x;
//     int y;

//     int b;
//     int s;
//     bool player;
//     bool machine;
//     bool result;
//     bool flag;

//     Click();

//     bool player1(int x, int y, int b, int s, bool player, bool machine, bool result);
//     // bool player2(int b, int s, bool player, bool result);

//     bool checkStat(std::vector<Rect> griddd, bool result, bool machine);
// };

// #endif






