// #include <iostream>
// #include <math.h>
// #include <vector>
// #include "click.h"
// #include "Rect.h"
// #include "winner.h"

// #if defined WIN32
// #include <freeglut.h>
// #elif defined __APPLE__
// #include <GLUT/glut.h>
// #else
// #include <GL/freeglut.h>
// #endif

// using namespace std;

// vector<Rect> gridd;
// Winner pass;


// Click::Click(){

//     x = 0;
//     y = 0;

//     b = 0;
//     s = 0;

//     player = true;
//     machine = true;
//     result = false;
//     flag = true;

// }


//  bool Click::checkStat(std::vector<Rect> griddd, bool result, bool machine){
//     if(pass.Xwinner(griddd)){
		
// 		cout << "X wins" << endl;
// 		cout << "Player 1 Won!" << endl;
		
// 		result = true;
// 		cout << "Rematch?? Press (a) to play against computer" << endl;
// 		cout << "Player vs. Player (Press p)" << endl;
// 	} 

// 	if(pass.Owinner(griddd)){
		
// 		cout << "O wins" << endl;
// 		// cout << "Rematch??" << endl;
// 		// cout << "Press (a) to play against computer" << endl;
// 		// cout << "Player vs. Player (Press p)" << endl;
// 		if(machine == true){
// 			//Text(GLUT_BITMAP_TIMES_ROMAN_24, "machine won", 95, 185);
// 			cout << "Machine won!" << endl;
// 			cout << "Rematch?? Press (a) to play against computer" << endl;
// 			cout << "Player vs. Player (Press p)" << endl;
			

// 			//AI goes here
// 		} else {
// 			// Text(GLUT_BITMAP_TIMES_ROMAN_24, "Player 2 won", 95, 185);
// 			cout << "Player 2 Won!" << endl;
// 			cout << "Rematch?? Press (a) to play against computer" << endl;
// 			cout << "Player vs. Player (Press p)" << endl;
// 		}
		
// 		result = true;
// 	}

// 	if(result != true){
// 		flag = true;
// 		for(int i = 0; i < griddd.size(); i++){
// 			if(griddd[i].occupied != true){
// 				flag = false;
// 				break;
// 			}
// 		}

// 		if(flag){
// 			result = true;
// 			cout << "Its a tie!" << endl;
// 			// cout << "Rematch?? Press (a)" << endl;
// 			// cout << "Player vs. Player (Press p)" << endl;
// 			// cout << "Player vs. Machine" << endl;
// 		}
// 	}
// }

// bool Click::player1(int x, int y, int b, int s, bool player, bool machine, bool result){
// if(s == 0){
// 		for(int i = 0; i < gridd.size(); i++){
// 			if((result != true)){
// 				if(gridd[i].contains(x,y)){
// 					if(gridd[i].occupied != true){
// 						if(player && gridd[i].occupied != true){						//checks player 1
// 							cout << "Player 1's turn!" << endl;
// 							cout << "###########################" << endl;
// 							gridd[i].shape = EX;
// 							gridd[i].occupied = true;
// 							player = !player;
// 						}

					

						
// 						gridd[i].occupied = true;
// 						player = !player;
// 					}

// 					checkStat(gridd, result, machine);	


// 					if(!player && result != true){
// 						for(int i = 0; i < gridd.size(); i++){
// 							if(gridd[i].occupied != true){
// 								gridd[i].shape = Circ;
// 								gridd[i].occupied = true;
// 								player = player;

// 								//cout << "Player 2's turn!" << endl;
// 								break;
// 							}
// 						}		
// 							gridd[i].shape = Circ;
// 					} else {					
// 							gridd[i].shape = EX;
// 					}


// 						//this is how the AI makes decisons
// 					if(machine && result != true){
// 						for(int i = 0; i < gridd.size(); i++){
// 							int choose = (rand() % (gridd.size() + 1)) + 0;
// 							if(gridd[choose].occupied != true){
// 								gridd[choose].shape = Circ;
// 								gridd[choose].occupied = true;
// 								player = !player;
// 								break;
// 							}
// 						}
// 						checkStat(gridd, result, machine);
// 					}
// 					break;
// 				}
// 			}
// 		}
// 	}
// }
